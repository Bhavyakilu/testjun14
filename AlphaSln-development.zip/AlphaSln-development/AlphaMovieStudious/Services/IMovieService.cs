using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Services;

public interface IMovieService
{
    IQueryable<Movie> Movies { get; }

    void AddMovie(Movie movie);
}