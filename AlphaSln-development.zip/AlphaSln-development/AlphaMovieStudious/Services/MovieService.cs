using AlphaMovieStudious.Data;
using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Services;

public class MovieService : IMovieService
{
    private readonly AppDbContext _context;

    public MovieService(AppDbContext context)
    {
        _context = context;
    }

    public IQueryable<Movie> Movies => _context.Movies;

    public void AddMovie(Movie movie)
    {
        if (movie == null)
        {
            throw new ArgumentNullException(nameof(movie), "Movie cannot be null");
        }
        _context.Movies.Add(movie);
        _context.SaveChanges();
    }
}