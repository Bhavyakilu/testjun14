namespace AlphaMovieStudious.Services;

public interface IOrderService
{
    
}