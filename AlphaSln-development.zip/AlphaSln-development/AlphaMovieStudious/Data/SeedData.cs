using Microsoft.EntityFrameworkCore;
using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Data;

public static class SeedData
{
    public static void EnsurePopulated(IApplicationBuilder app)
    {
        AppDbContext context = app.ApplicationServices
            .CreateScope().ServiceProvider.GetRequiredService<AppDbContext>();

        if (context.Database.GetPendingMigrations().Any())
            context.Database.Migrate();

        if (!context.Movies.Any())
        {
            context.Movies.AddRange(
                new Movie
                {
                    Title = "Inception",
                    Genre = MovieGenre.SciFi,
                    Director = "Christopher Nolan",
                    Year = 2010,
                    Price = 14.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2021/11/2/j9a49d3b3b38dmw11n94d.jpeg"
                },
                new Movie
                {
                    Title = "The Shawshank Redemption",
                    Genre = MovieGenre.Drama,
                    Director = "Frank Darabont",
                    Year = 1994,
                    Price = 9.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2021/3/6/o41759bd352dazn54q16d.jpeg"
                },
                new Movie
                {
                    Title = "The Godfather",
                    Genre = MovieGenre.Drama,
                    Director = "Francis Ford Coppola",
                    Year = 1972,
                    Price = 12.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2024/3/2/l2c933aeeeef7ry57l39g.jpeg"
                },
                new Movie
                {
                    Title = "Pulp Fiction",
                    Genre = MovieGenre.Drama,
                    Director = "Quentin Tarantino",
                    Year = 1994,
                    Price = 11.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2021/3/17/q6e275b47b126xt59x65c.jpeg"
                },
                new Movie
                {
                    Title = "The Dark Knight",
                    Genre = MovieGenre.Action,
                    Director = "Christopher Nolan",
                    Year = 2008,
                    Price = 13.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2025/5/27/k53dfafef98a0zl27l28u.jpeg"
                },
                new Movie
                {
                    Title = "Forrest Gump",
                    Genre = MovieGenre.Drama,
                    Director = "Robert Zemeckis",
                    Year = 1994,
                    Price = 10.99m,
                    ImageUrl = "https://statichdrezka.ac/i/2013/11/24/f8cfabd5b4fb8lh96z58u.jpg"
                },
                new Movie
                {
                    Title = "Fight Club",
                    Genre = MovieGenre.Drama,
                    Director = "David Fincher",
                    Year = 1999,
                    Price = 9.49m,
                    ImageUrl = "https://statichdrezka.ac/i/2025/5/30/z858b603058b2ek36y62t.jpeg"
                },
                new Movie
                {
                    Title = "The Matrix",
                    Genre = MovieGenre.SciFi,
                    Director = "Lana Wachowski, Lilly Wachowski",
                    Year = 1999,
                    Price = 12.49m,
                    ImageUrl = "https://statichdrezka.ac/i/2014/1/22/h4442e483f19aey57g75d.jpg"
                }
            );
            context.SaveChanges();
        };
    }
}