using AlphaMovieStudious.Models;

namespace AlphaMovieStudious.Models.ViewModels;

public class ShoppingCartViewModel
{
    public IShoppingCart ShoppingCart { get; set; }
    public decimal ShoppingCartTotal { get; }
    
    public ShoppingCartViewModel(IShoppingCart shoppingCart, decimal shoppingCartTotal)
    {
        ShoppingCart = shoppingCart;
        ShoppingCartTotal = shoppingCartTotal;
    }
}