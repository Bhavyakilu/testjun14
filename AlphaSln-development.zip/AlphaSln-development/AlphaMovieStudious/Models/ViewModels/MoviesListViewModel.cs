using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Models.ViewModels;

public class MoviesListViewModel
{
    public IEnumerable<Movie> Movies { get; set; } = Enumerable.Empty<Movie>();
    
    public PagingInfo PagingInfo { get; set; } = new();
    
    public MovieGenre? CurrentGenre { get; set; }
}