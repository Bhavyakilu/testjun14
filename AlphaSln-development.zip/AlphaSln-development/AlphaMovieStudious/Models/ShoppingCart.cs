using Microsoft.EntityFrameworkCore;
using AlphaMovieStudious.Models.Db;
using AlphaMovieStudious.Data;

namespace AlphaMovieStudious.Models;

public class ShoppingCart(AppDbContext context) : IShoppingCart
{
    public string? ShoppingCartId { get; set; }
    
    public List<ShoppingCartItem> ShoppingCartItems { get; set; } = default!;

    public static ShoppingCart GetShoppingCart(IServiceProvider services)
    {
        ISession? session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext?.Session;
        AppDbContext? context = services.GetService<AppDbContext>() ?? throw new Exception("Error Initializing ShoppingCart");
        string cartId = session?.GetString("CartId") ?? Guid.NewGuid().ToString();
        session?.SetString("CartId", cartId);
        return new ShoppingCart(context) { ShoppingCartId = cartId };
    }

    public void AddToCart(Movie movie)
    {
        var shoppingCartItem = context.ShoppingCartItems
            .SingleOrDefault(s => s.Movie.Id == movie.Id && s.ShoppingCartId == ShoppingCartId);

        if (shoppingCartItem == null)
        {
            shoppingCartItem = new ShoppingCartItem
            {
                ShoppingCartId = ShoppingCartId,
                Movie = movie,
                Amount = 1
            };
            context.ShoppingCartItems.Add(shoppingCartItem);
        }
        else
        {
            shoppingCartItem.Amount++;
        }
        context.SaveChanges();
    }

    public void RemoveFromCart(Movie movie)
    {
        var shoppingCartItem = context.ShoppingCartItems
            .SingleOrDefault(s => s.Movie.Id == movie.Id && s.ShoppingCartId == ShoppingCartId);
        var localAmount = 0;
        if (shoppingCartItem != null)
        {
            if (shoppingCartItem.Amount > 1)
            {
                shoppingCartItem.Amount--;
                localAmount = shoppingCartItem.Amount;
            }
            else
            {
                context.ShoppingCartItems.Remove(shoppingCartItem);
            }
        }
        
        context.SaveChanges();
    }

    public List<ShoppingCartItem> GetShoppingCartItems()
    {
        return ShoppingCartItems ??= context.ShoppingCartItems
            .Where(c => c.ShoppingCartId == ShoppingCartId)
            .Include(c => c.Movie)
            .ToList();
    }

    public void ClearCart()
    {
        var cartItems = context.ShoppingCartItems
            .Where(c => c.ShoppingCartId == ShoppingCartId);
        context.ShoppingCartItems.RemoveRange(cartItems);
        context.SaveChanges();
    }

    public decimal GetShoppingCartTotal()
    {
        var total = context.ShoppingCartItems
            .Where(c => c.ShoppingCartId == ShoppingCartId)
            .Sum(c => c.Movie.Price * c.Amount);
        return total;
    }
}