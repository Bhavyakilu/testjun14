using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Models;

public interface IShoppingCart
{
    void AddToCart(Movie movie);
    
    void RemoveFromCart(Movie movie);
    
    List<ShoppingCartItem> GetShoppingCartItems();
    
    void ClearCart();
    decimal GetShoppingCartTotal();
    
    List<ShoppingCartItem> ShoppingCartItems { get; set; }
}