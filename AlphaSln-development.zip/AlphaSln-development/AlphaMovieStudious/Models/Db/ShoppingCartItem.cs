namespace AlphaMovieStudious.Models.Db;

public class ShoppingCartItem
{
    public int ShoppingCartItemId { get; set; }
    public Movie Movie { get; set; } = default!;
    public int Amount { get; set; }
    public string? ShoppingCartId { get; set; }
}