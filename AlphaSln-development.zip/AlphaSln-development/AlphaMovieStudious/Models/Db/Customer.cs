using System.ComponentModel.DataAnnotations;

namespace AlphaMovieStudious.Models.Db;

public class Customer
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public required string FirstName { get; set; }

    [Required]
    [StringLength(100)]
    public required string LastName { get; set; }

    [Required]
    [StringLength(100)]
    public required string BillingAddress { get; set; }

    [Required]
    [MaxLength(8, ErrorMessage = "Zip code length cant go up the 8 char limit")]
    public int BillingZip { get; set; }

    [Required]
    [StringLength(100)]
    public required string BillingCity { get; set; }

    [Required]
    [StringLength(100)]
    public required string DeliveryAddress { get; set; }

    [Required]
    [MaxLength(8, ErrorMessage = "max length of zip cant go up the 8 char limit")]
    public int DeliveryZip { get; set; }

    [Required]
    [StringLength(100)]
    public required string DeliveryCity { get; set; }

    [Required]
    [EmailAddress]
    [StringLength(255)]
    public required string Email { get; set; }

    [Required]
    [Phone]
    [StringLength(20)]
    public required string PhoneNo { get; set; }
}