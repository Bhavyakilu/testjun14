using System.ComponentModel.DataAnnotations;

namespace AlphaMovieStudious.Models.Db;

public class Order
{
    [Key]
    [Required]
    public int Id { get; set; }

    [Required]
    [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:yyyy/MM/dd}")]
    public DateTime OrderDate { get; set; } = DateTime.Now;

    [Required]
    public int CustomerId { get; set; }
}