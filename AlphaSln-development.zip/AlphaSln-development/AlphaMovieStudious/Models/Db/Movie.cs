using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AlphaMovieStudious.Models.Db;

public class Movie
{
    [Key]
    public int Id { get; set; }
    
    [Required]
    [StringLength(100)]
    public required string Title { get; set; }
    
    public MovieGenre? Genre { get; set; }
    
    [StringLength(200)]
    public string? ImageUrl { get; set; }
    
    [Required]
    [StringLength(100)]
    public required string Director { get; set; }
    
    [Required]
    public int Year { get; set; }
    
    [Required]
    [Column(TypeName = "money")]
    public decimal Price { get; set; }
}

public enum MovieGenre
{
    Action,
    Adventure,
    Animation,
    Comedy,
    Documentary,
    Drama,
    Horror,
    Romance,
    SciFi,
    Thriller
}