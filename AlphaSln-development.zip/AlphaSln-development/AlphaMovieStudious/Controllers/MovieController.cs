using Microsoft.AspNetCore.Mvc;
using AlphaMovieStudious.Services;
using AlphaMovieStudious.Models.ViewModels;
using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Controllers;

public class MovieController : Controller
{
    private readonly IMovieService _movieService;
    public int PageSize = 4;

    public MovieController(IMovieService movieService)
    {
        _movieService = movieService;
    }

    public ViewResult Index(MovieGenre? genre, int moviePage = 1)
        => View(new MoviesListViewModel
        {
            Movies = _movieService.Movies
                .Where(m => genre == null || m.Genre == genre)
                .OrderBy(m => m.Title)
                .Skip((moviePage - 1) * PageSize)
                .Take(PageSize),
            PagingInfo = new PagingInfo
            {
                CurrentPage = moviePage,
                ItemsPerPage = PageSize,
                TotalItems = genre == null
                    ? _movieService.Movies.Count()
                    : _movieService.Movies.Count(m => m.Genre == genre),
            },
            CurrentGenre = genre
        });


    public IActionResult Create()
    {
        return View();
    }

    public IActionResult Create(Movie movie)
    {
        if (ModelState.IsValid)
        {
            _movieService.AddMovie(movie);
            return RedirectToAction(nameof(Index));
        }
        return View(movie);
    }
}

