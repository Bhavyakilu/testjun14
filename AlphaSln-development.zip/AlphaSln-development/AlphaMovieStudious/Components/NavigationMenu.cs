using Microsoft.AspNetCore.Mvc;
using AlphaMovieStudious.Models.Db;

namespace AlphaMovieStudious.Components;

public class NavigationMenu : ViewComponent
{
    public IViewComponentResult Invoke()
    {
        ViewBag.SelectedGenre = RouteData?.Values["genre"] ?? "All";
        List<string> genres = Enum.GetNames(typeof(MovieGenre)).ToList();
        return View(genres);
    }
}