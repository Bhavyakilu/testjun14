using Microsoft.EntityFrameworkCore;
using AlphaMovieStudious.Data;
using AlphaMovieStudious.Models;
using AlphaMovieStudious.Services;

var builder = WebApplication.CreateBuilder(args);

// Register services
builder.Services.AddControllersWithViews();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(opts =>
    opts.UseSqlServer(connectionString));

builder.Services.AddScoped<IMovieService, MovieService>();
// builder.Services.AddScoped<IOrderService, OrderService>();

builder.Services.AddScoped<IShoppingCart, ShoppingCart>(sp => ShoppingCart.GetShoppingCart(sp));
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

// ----------------------------------------
var app = builder.Build();

// Configure the HTTP request pipeline

app.UseStaticFiles();
app.UseSession();

app.MapControllerRoute("genpage", 
    "Movie/{genre}/Page{moviePage:int}", 
    new { Controller = "Movie", action = "Index" });

app.MapControllerRoute("page",
    "Movie/Page{moviePage:int}",
    new { Controller = "Movie", action = "Index", moviePage = 1 });

app.MapControllerRoute("genre",
    "Movie/{genre}",
    new { Controller = "Movie", action = "Index", moviePage = 1 });

app.MapControllerRoute("pagination",
    "Movie/Page{moviePage}",
    new { Controller = "Movie", action = "Index", moviePage = 1 });

app.MapDefaultControllerRoute();

// ----------------------------------------

SeedData.EnsurePopulated(app);

app.Run();